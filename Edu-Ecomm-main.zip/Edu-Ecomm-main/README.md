# Edu-Ecomm
This is a Sample E-Commerce Project 
For Admin Login Use This url:http://localhost:4200/adminlogin
username:admin@123.com
password:lk@#1427

Note:
In Backend E-Commerce -1, you have to change your username and password in application.properties file.
